document.addEventListener('DOMContentLoaded', function() {
    const btn = document.getElementById('actionBtn');
    if (btn) {
        btn.addEventListener('click', function() {
            this.textContent = 'Experience complete';
           
            console.log('按钮已点击，文字已更改');
        });
    }
});